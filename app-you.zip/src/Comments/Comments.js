import React from 'react'
import './Comments.css'

export default function Comments() {
  return (
    <div>
      <section className="testimonial-area" id="testimonial_page">
        <div className="container">
            <div className="row">
                <div className="col-xs-12">
                    <div className="paagee-tiitle textt-centerr">
                        <h5 className="comments">نظرات</h5>
                        <h3 className="darrk-colorr">مشتریان ما را دوست دارند</h3>
                        <div className="space-60"></div>
                    </div>
                </div>
            </div>
            <div className="row">
                <div className="col-xs-12">
                    <div className="team-slide owl-carousel owl-theme owl-responsive-1000 owl-loaded">
                        <div className="owl-stage-outer">
                            <div className="owl-stage">
                                <div className="owl-item cloned">
                                    <div className="team-box">
                                        <div className="team-image">
                                            <img className='t-img' src="images/team-1.png" alt=""></img>
                                        </div>
                                        <h4>ملیکا خلیلیان</h4>
                                        <h6 className="position">کارگردان هنری</h6>
                                        <span className='p-class'>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است</span>
                                    </div>
                                </div>
                                <div className="owl-item cloned">
                                    <div className="team-box">
                                        <div className="team-image">
                                            <img className='t-img' src="images/team-2.png" alt=""></img>
                                        </div>
                                        <h4>ملیکا خلیلیان</h4>
                                        <h6 className="position">کارگردان هنری</h6>
                                        <span className='p-class'>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است</span>
                                    </div>
                                </div>
                                <div className="owl-item cloned">
                                    <div className="team-box">
                                        <div className="team-image">
                                            <img className='t-img' src="images/team-3.png" alt=""></img>
                                        </div>
                                        <h4>ملیکا خلیلیان</h4>
                                        <h6 className="position">کارگردان هنری</h6>
                                        <span className='c-class'>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است</span>
                                    </div>
                                </div>
                                <div className="owl-item">
                                    <div className="team-box">
                                        <div className="team-image">
                                            <img className='t-img' src="images/team-1.png" alt=""></img>
                                        </div>
                                        <h4>ملیکا خلیلیان</h4>
                                        <h6 className="position">کارگردان هنری</h6>
                                        <span className='p-class'>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است</span>
                                    </div>
                                </div>
                                <div className="owl-item">
                                    <div className="team-box">
                                        <div className="team-image">
                                            <img className='t-img' src="images/team-2.png" alt=""></img>
                                        </div>
                                        <h4>ملیکا خلیلیان</h4>
                                        <h6 className="position">کارگردان هنری</h6>
                                        <span className='p-class'>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است</span>
                                    </div>
                                </div>
                                <div className="owl-item">
                                    <div className="team-box">
                                        <div className="team-image">
                                            <img className='t-img' src="images/team-3.png" alt=""></img>
                                        </div>
                                        <h4>ملیکا خلیلیان</h4>
                                        <h6 className="position">کارگردان هنری</h6>
                                        <span className='p-class'>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="owl-controls">
                            <div className="owl-nav">
                                <div className="owl-prev">
                                    <i className="left-right lnr-chevron-left">
                                        <svg className='chavron' xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" />
                                        </svg>
                                    </i>
                                </div>
                                <div className="owl-next">
                                    <i className="left-right lnr-chevron-right">
                                        <svg className='chavron' xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                        </svg>
                                    </i>
                                </div>
                            </div>
                            <div className="owl-dots">
                                <div className="owl-dot">
                                    <span></span>
                                </div>
                                <div className="owl-dot active">
                                    <span></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    </div>
  )
}
