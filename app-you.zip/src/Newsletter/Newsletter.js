import React from 'react'
import './Newsletter.css'

export default function Newsletter() {
  return (
    <div>
      <div className="subscribe-area seectionn-padding">
        <img className='n-sub' src='./images/subscribe-bg.jpg'></img>
        <div className="container">
            <div className="row">
                <div className="col-xs-12 col-sm-8 col-sm-offset-2">
                    <div className="subscribe-form text-ceennter">
                        <h3 className="blue-color">برای ویژگی های بیشتر در خبرنامه ما عضو شوید</h3>
                        <div className="space-20"></div>
                        <form id="mc-form" novalidate="true">
                            <input type="email" className="control" placeholder="ایمیل خود را وارد کنید." required="required" id="mc-email" name="EMAIL"></input>
                            <button className="n-bttn active" type="submit">
                                <span className="news lnr-location">
                                    <img className='paper' src='./images/paper.svg'></img>
                                </span> 
                                عضویت
                            </button>
                            <label className="mt10" for="mc-email"></label>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
  )
}
