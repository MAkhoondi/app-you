import React from 'react'
import './Download.css'

export default function Download() {
  return (
    <div>
      <div className='download-area overlay'>
            <img id='download-bg' src='./images/download-bg.jpg'></img>
            <div className="container">
                <div className="row">
                    <div className="col-xs-12 col-sm-6 hidden-sm">
                        <figure className="mb-image">
                            <img id='download-image' src="./images/download-image.png" alt=""></img>
                        </figure>
                    </div>
                    <div className="col-xs-12 col-md-6 sectionn-padding">
                        <h3 className="white-colorr">برنامه را دانلود کنید</h3>
                        <div className="space-20"></div>
                        <span id='p-download'>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است</span>
                        <div className="space-60"></div>
                        <button href="#" className="bttnn-down sq">
                            <img className='app' src="./images/apple-icon.png" alt="apple icon"></img>
                            <span className='text-down'>فروشگاه اپل</span>
                        </button>
                        <button href="#" className="bttnn-down sq">
                            <img className='apps' src="./images/play-store-icon.png" alt="Play Store Icon"></img>
                            <span className='text-down1'>پلی استور</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
  )
}
