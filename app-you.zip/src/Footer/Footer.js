import React from 'react'
import './Footer.css'

export default function Footer() {
  return (
    <div>
      <footer className="footer-area" id="contact_page">
        <div className="sseection-padding">
            <div className="container">
                <div className="row">
                    <div className="col-xs-12">
                        <div className="pagee-titlee textt-ccenter">
                            <h5 className="titleee">تماس با ما</h5>
                            <h3 className="darkk-ccolor">ما را با جزئیات زیر پیدا کنید</h3>
                            <div className="space-60"></div>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col-xs-12 col-sm-4">
                        <div className="footer-box">
                            <div className="boxx-iicon">
                                <span className="iiocon lnr-map-marker">
                                    <svg id='f-map' xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" className="size-6">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1 1 15 0Z" />
                                    </svg>
                                </span>
                            </div>
                            <p className='p-footer'>ایران، شاهرود <br/>شرکت بین المللی اپ یو</p>
                        </div>
                        <div className="space-30 hidden visible-xs"></div>
                    </div>
                    <div className="col-xs-12 col-sm-4">
                        <div className="footer-box">
                            <div className="boxx-iicon">
                                <span className="iicon lnr-phone-handset">
                                    <svg id='f-phone' xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" className="size-6">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 0 0 2.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 0 1-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 0 0-1.091-.852H4.5A2.25 2.25 0 0 0 2.25 4.5v2.25Z" />
                                    </svg>
                                </span>
                            </div>
                            <p className='p-footer'>09107195382 <br/>021-223366585</p>
                        </div>
                        <div className="space-30 hidden visible-xs"></div>
                    </div>
                    <div className="col-xs-12 col-sm-4">
                        <div className="footer-box">
                            <div className="boxx-iicon">
                                <span className="iicon lnr-envelope">
                                    <svg id='f-email' xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" className="size-6">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 0 1-2.25 2.25h-15a2.25 2.25 0 0 1-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25m19.5 0v.243a2.25 2.25 0 0 1-1.07 1.916l-7.5 4.615a2.25 2.25 0 0 1-2.36 0L3.32 8.91a2.25 2.25 0 0 1-1.07-1.916V6.75" />
                                    </svg>
                                </span>
                            </div>
                            <p className='p-footer'>yourmail@gmail.com <br/> sample@gmail.com</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div className="footer-bottom">
            <div className="container">
                <div className="row">
                    <div className="col-xs-12 col-md-5">
                        <span className='f-copy'>کپی رایت ©<script>document.write(new Date().getFullYear());</script>2024 تمامی حقوق محفوظ است <i class="lnr lnr-heart" aria-hidden="true"></i> برای <a className='AM' href="https://aliniyazi.info/" target="_blank">Akhoondi Bros</a></span>
                    <div className="space-30 hidden visible-xs"></div>
                </div>
                <div className="col-xs-12 col-md-7">
                    <div className="footer-menu">
                        <ul className='footer-list'>
                            <li className='li-footer'><a className='a-footer' href="#">درباره ی ما</a></li>
                            <li className='li-footer'><a className='a-footer' href="#">خدمات</a></li>
                            <li className='li-footer'><a className='a-footer' href="#">ویژگی ها</a></li>
                            <li className='li-footer'><a className='a-footer' href="#">قیمت</a></li>
                            <li className='li-footer'><a className='a-footer' href="#">نظرات</a></li>
                            <li className='li-footer'><a className='a-footer' href="#">تماس با ما</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </footer>
</div>
  )
}
