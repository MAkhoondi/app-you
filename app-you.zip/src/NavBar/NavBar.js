import React from 'react'
import './NavBar.css'

export default function NavBar() {
  return (
    <div>
      <nav className='minmenu-area'>
            <div className='container-fluid'>
                <div className='navbar-header'>
                    <a className='navbar-brand' href='#'>
                        <img className='logo-nav' src='./images/logo.png' alt='Logo'></img>
                    </a>
                </div>
                <div id='primary-menu' className='collapse navbar-collapse'>
                    <ul id='ul-nav' className='nav navbar-nav mainmenu'>
                        <li className='active'>
                            <a href='#home_page'>خانه</a>
                        </li>
                        <li>
                            <a href='#about-page'>درباره ی ما</a>
                        </li>
                        <li>
                            <a href='#features-page'>ویژگی ها</a>
                        </li>
                        <li>
                            <a href='#gallery-page'>گالری</a>
                        </li>
                        <li>
                            <a href='#price-page'>قیمت</a>
                        </li>
                        <li>
                            <a href='question-page'>سوالات پر تکرار</a>
                        </li>
                        <li>
                            <a href='blog.html'>وبلاگ</a>
                        </li>
                        <li>
                            <a href='contact-page'>تماس با ما</a>
                        </li>
                    </ul>
                    <div className='right-button hidden-xs'>
                        <button id='signup-button' href='#'>ثبت نام</button>
                    </div>
                </div>
            </div>
        </nav> 
    </div>
  )
}
