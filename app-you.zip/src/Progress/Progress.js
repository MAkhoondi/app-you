import React from 'react'
import './Progress.css'

export default function Progress() {
  return (
    <div>
        <section className="progress-area gray-bg" id="progress_page">
            <img className='screen' src='images/progress-bg.jpg'></img>
            <div className="container">
                <div className="row">
                    <div className="col-xs-12 col-md-6">
                        <div className="paage-title secction-padding">
                            <h5 className="improve wow fadeInUp">پیشرفت ما</h5>
                            <div className="space-10"></div>
                            <h3 className="daark-color wow fadeInUp">برنامه گرت برای همیشه</h3>
                            <div className="space-20"></div>
                            <div className="desc wow fadeInUp">
                                <p className='p-progress'>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان<br/> گرافیک است چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است</p>
                            </div>
                            <div className="space-50"></div>
                            <button href="#" className="prog-bttn wow fadeInUp"><span className='b-prog'>بیشتر بدانید</span></button>
                        </div>
                    </div>
                    <div className="col-xs-12 col-md-6">
                        <figure className="mobile-image">
                            <img className='mobile-chat' src="images/progress-phone.png" alt=""></img>
                        </figure>
                    </div>
                </div>
            </div>
        </section>
    </div>
  )
}
