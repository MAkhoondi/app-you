import React from 'react'
import './About.css'

export default function About() {
  return (
    <div>
        <section className="secttion-padding" id="about_page">
            <div className="container">
                <div className="row">
                    <div class="col-xs-12 col-md-10 col-md-offset-1">
                        <div className="p_title page-title text-center">
                            <img src='images/about-logo.png' class='about'></img>
                            <div className="space-20"></div>
                            <h5 className="title">درباره اپ یو</h5>
                            <div className="space-30"></div>
                            <h3 className="blue-color">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان<br/> گرافیک است چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است</h3>
                            <div className="space-20"></div>
                            <span>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است چاپگرها و متون بلکه روزنامه و مجله در ستون و<br/> سطرآنچنان که لازم است</span>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
  )
}
