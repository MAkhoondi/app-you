import React from 'react'
import './Screenshots.css'

export default function Screenshots() {
  return (
    <div>
      <section className="gallery-area section-paddingg" id="gallery_page">
            <div className="container-fluid">
                <div className="row">
                    <div className="col-xs-12 col-sm-6 gallery-slider">
                        <div className="gallery-slide owl-carousell owl-theme owl-responsive-1500 owl-loadedd">
                            <div className='owl-stage-outerr'>
                                <img className='mb-screen' src='./images/mobile-screen.png'></img>
                                <div className='owl-stagee'>
                                    <div className='owl-itemm cloned'>
                                        <div className='item'>
                                            <img className='gallery4' src='./images/gallery-4.jpg'></img>
                                        </div>
                                    </div>
                                    <div className='owl-itemm cloned'>
                                        <div className='item'>
                                            <img className='gallery1' src='./images/gallery-1.jpg'></img>
                                        </div>
                                    </div>
                                    <div className='owl-itemm cloned'>
                                        <div className='item'>
                                            <img className='gallery2' src='./images/gallery-2.jpg'></img>
                                        </div>
                                    </div>
                                    <div className='owl-itemm cloned'>
                                        <div className='item'>
                                            <img className='gallery3' src='./images/gallery-3.jpg'></img>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className='owl-controlss'>
                            <div className='owl-dotss'>
                                <div class="owll-dot active">
                                    <span></span>
                                </div>
                                <div className="owll-dot">
                                    <span></span>
                                </div>
                                <div className="owll-dot">
                                        <span></span>
                                </div>
                                <div className="owll-dot">
                                    <span></span>
                                </div>
                            </div>
                        </div>
                        <div className="col-xs-12 col-sm-5 col-lg-3 s-full">
                            <div className="page-titllle">
                                <h5 className="whhhite-color titllle wow fadeInUp">اسکرین شات</h5>
                                <div className="space-10"></div>
                                <h3 className="sc01 wow fadeInUp">اسکرین شات 01</h3>
                            </div>
                            <div className="space-20"></div>
                            <div className="desc wow fadeInUp">
                                <p className='p-shot'>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از<br/> صنعت چاپ و با استفاده از طراحان گرافیک است چاپگرها<br/> و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که<br/> لازم است</p>
                            </div>
                            <div className="space-50"></div>
                            <button href="#" className="bttn-defaultt wow fadeInUp"><span id='sc-know'>بیشتر بدانید</span></button>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
  )
}
