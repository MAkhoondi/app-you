import React from 'react'
import './ScrollUp.css'

export default function ScrollUp() {
  return (
    <div>
        <a id="scrollUp" href="#top">
            <i className="up lnr-arrow-up">
            <svg id='arrow-up' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                <path d="M13.0001 7.82843V20H11.0001V7.82843L5.63614 13.1924L4.22192 11.7782L12.0001 4L19.7783 11.7782L18.3641 13.1924L13.0001 7.82843Z"></path>
            </svg>
            </i>
        </a>
    </div>
  )
}
