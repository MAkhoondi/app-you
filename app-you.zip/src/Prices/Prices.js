import React from 'react'
import './Prices.css'

export default function Prices() {
  return (
    <div>
      <section className="sectiion-paddiiing price-area" id="price_page">
        <div className="container">
            <div className="row">
                <div className="col-xs-12">
                    <div className="page-titllee textt-centter">
                        <h5 className="price">برنامه قیمت گذاری</h5>
                        <h3 classclassName="darkk-coloorr">برنامه عالی قیمت گذاری</h3>
                        <div className="space-60"></div>
                    </div>
                </div>
            </div>
            <div className="row">
                <div className="col-xs-12 col-sm-4">
                    <div className="price-box">
                        <div className="price-header">
                            <div className="price-icon">
                                <span className="ico lnr-rockett">
                                    <svg id='rockett' xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M15.59 14.37a6 6 0 0 1-5.84 7.38v-4.8m5.84-2.58a14.98 14.98 0 0 0 6.16-12.12A14.98 14.98 0 0 0 9.631 8.41m5.96 5.96a14.926 14.926 0 0 1-5.841 2.58m-.119-8.54a6 6 0 0 0-7.381 5.84h4.8m2.581-5.84a14.927 14.927 0 0 0-2.58 5.84m2.699 2.7c-.103.021-.207.041-.311.06a15.09 15.09 0 0 1-2.448-2.448 14.9 14.9 0 0 1 .06-.312m-2.24 2.39a4.493 4.493 0 0 0-1.757 4.306 4.493 4.493 0 0 0 4.306-1.758M16.5 9a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0Z" />
                                    </svg>
                                </span>
                            </div>
                            <h4 className="upper">رایگان</h4>
                        </div>
                        <div className="price-body">
                            <ul>
                                <li>نصب آسان</li>
                                <li>پشتیبانی نامحدود</li>
                                <li>عناصر منحصر به فرد</li>
                            </ul>
                        </div>
                        <div className="price-rate">
                            <sup>ماهیانه</sup>
                            <span className="rate">0</span> 
                            <small>/ تومان</small>
                        </div>
                        <div className="price-footer">
                            <button href="#" className="p-button">خرید</button>
                        </div>
                    </div>
                    <div className="space-30 hidden visible-xs"></div>
                </div>
                <div className="col-xs-12 col-sm-4">
                    <div className="price-box">
                        <div className="price-header">
                            <div className="price-icon">
                                <span className="ico lnr-diamond">
                                    <svg id='diamond' height="21" viewBox="0 0 21 21" width="21" xmlns="http://www.w3.org/2000/svg">
                                        <g fill="none" fill-rule="evenodd" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" transform="translate(2 4)">
                                            <path d="m13.5 0 3 4-8 10-8-10 3.009-4z"/>
                                            <path d="m.5 4h16"/>
                                            <path d="m5.5 4 3 10"/>
                                            <path d="m11.5 4-3 10"/>
                                            <path d="m3.509 0 1.991 4 3-4 3 4 2-4"/>
                                        </g>
                                    </svg>
                                </span>
                            </div>
                            <h4 className="upper">متوسط</h4>
                        </div>
                        <div className="price-body">
                            <ul>
                                <li>نصب آسان</li>
                                <li>پشتیبانی نامحدود</li>
                                <li>همیشه رایگان</li>
                            </ul>
                        </div>
                        <div className="price-rate">
                            <sup>ماهیانه</sup> 
                            <span className="rate">49000</span> 
                            <small>/ تومان</small>
                        </div>
                        <div className="price-footer">
                            <button href="#" className="p-button">خرید</button>
                        </div>
                    </div>
                    <div className="space-30 hidden visible-xs"></div>
                </div>
                <div className="col-xs-12 col-sm-4">
                    <div className="price-box">
                        <div className="price-header">
                            <div className="price-icon">
                                <span class="ico lnr-pie-chart">
                                    <svg id='chart' xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M10.5 6a7.5 7.5 0 1 0 7.5 7.5h-7.5V6Z" />
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M13.5 10.5H21A7.5 7.5 0 0 0 13.5 3v7.5Z" />
                                    </svg>
                                </span>
                            </div>
                            <h4 class="upper upper3">بیزینس</h4>
                        </div>
                        <div class="price-body">
                            <ul>
                                <li>نصب آسان</li>
                                <li>پشتیبانی نامحدود</li>
                                <li>همیشه رایگان</li>
                            </ul>
                        </div>
                        <div class="price-rate">
                        <sup>ماهیانه</sup> <span class="rate">99000</span> <small>/ تومان</small>
                    </div>
                    <div class="price-footer">
                        <button href="#" class="p-button">خرید</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </section>
</div>
  )
}
