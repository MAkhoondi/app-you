import React from 'react'
import './Questions.css'

export default function Questions() {
  return (
    <div>
      <section id="questions_page" className="questions-area seectionn-paddingg">
            <div className="container">
                <div className="row">
                    <div className="col-xs-12">
                        <div className="pagge-title texxt-center">
                            <h5 className="tiitle">سوالات پر تکرار</h5>
                            <h3 className="dark-coloor">سوالات پر تکرار</h3>
                            <div className="space-60"></div>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col-xs-12 col-sm-6">
                        <div className="toggole-boxs ui-accordion ui-widget ui-helper-reset" role="tablist">
                            <h3 className="ui-accordion-header ui-corner-top ui-state-default ui-accordion-icons ui-accordion-header-collapsed ui-corner-all" role="tab" id="ui-id-1" aria-controls="ui-id-2" aria-selected="false" aria-expanded="false" tabindex="-1">
                            <span className="ui-accordion-header-icon ui-icon ui-icon-triangle-1-e"></span>اولین سوال پر تکرار اینجاست؟</h3>
                            <div className="ui-accordion-content ui-corner-bottom ui-helper-reset ui-widget-content" id="ui-id-2" aria-labelledby="ui-id-1" role="tabpanel" aria-hidden="true">
                                <p className='p-question'>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز</p>
                            </div>
                            <h3 className="ui-accordion-header ui-corner-top ui-state-default ui-accordion-icons ui-accordion-header-active ui-state-active" role="tab" id="ui-id-3" aria-controls="ui-id-4" aria-selected="true" aria-expanded="true" tabindex="0"><span className="ui-accordion-header-icon ui-icon ui-icon-triangle-1-s"></span>درباره سوال freewuent اینجا می روید؟ </h3>
                            <div className="ui-accordion-content ui-corner-bottom ui-helper-reset ui-widget-content ui-accordion-content-active" id="ui-id-4" aria-labelledby="ui-id-3" role="tabpanel" aria-hidden="false">
                                <p className='p1-question'>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز</p>
                            </div>
                            <h3 className="ui-accordion-header ui-corner-top ui-accordion-header-collapsed ui-corner-all ui-state-default ui-accordion-icons" role="tab" id="ui-id-5" aria-controls="ui-id-6" aria-selected="false" aria-expanded="false" tabindex="-1"><span className="ui-accordion-header-icon ui-icon ui-icon-triangle-1-e"></span>چرا بیشتر سوالات اینجاست؟ </h3>
                            <div className="ui-accordion-content ui-corner-bottom ui-helper-reset ui-widget-content" id="ui-id-6" aria-labelledby="ui-id-5" role="tabpanel" aria-hidden="true">
                                <p className='p2-question'>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز</p>
                            </div>
                            <h3 className="ui-accordion-header ui-corner-top ui-accordion-header-collapsed ui-corner-all ui-state-default ui-accordion-icons" role="tab" id="ui-id-7" aria-controls="ui-id-8" aria-selected="false" aria-expanded="false" tabindex="-1"><span classNameN="ui-accordion-header-icon ui-icon ui-icon-triangle-1-e"></span>چه سوالاتی اینجاست؟</h3>
                            <div className="ui-accordion-content ui-corner-bottom ui-helper-reset ui-widget-content" id="ui-id-8" aria-labelledby="ui-id-7" role="tabpanel" aria-hidden="true">
                                <p className='p3-question'>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز</p>
                            </div>
                            <br/>
                        </div>
                    </div>
                    <div className="col-xs-12 col-sm-6">
                        <div className="space-20 hidden visible-xs"></div>
                        <div className="toggole-boxs ui-accordion ui-widget ui-helper-reset" role="tablist">
                            <h3 className="ui-accordion-header ui-corner-top ui-state-default ui-accordion-icons ui-accordion-header-active ui-state-active" role="tab" id="ui-id-9" aria-controls="ui-id-10" aria-selected="true" aria-expanded="true" tabindex="0"><span className="ui-accordion-header-icon ui-icon ui-icon-triangle-1-s"></span>سوالات پر تکرار دوم اینجاست؟ </h3>
                            <div className="ui-accordion-content ui-corner-bottom ui-helper-reset ui-widget-content ui-accordion-content-active" id="ui-id-10" aria-labelledby="ui-id-9" role="tabpanel" aria-hidden="false">
                                <p className='p4-qusetion'>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز</p>
                            </div>
                            <h3 className="ui-accordion-header ui-corner-top ui-state-default ui-accordion-icons ui-accordion-header-collapsed ui-corner-all" role="tab" id="ui-id-11" aria-controls="ui-id-12" aria-selected="false" aria-expanded="false" tabindex="-1"><span className="ui-accordion-header-icon ui-icon ui-icon-triangle-1-e"></span>سوالات پر تکرار سوم اینجاست؟ </h3>
                                <div className="ui-accordion-content ui-corner-bottom ui-helper-reset ui-widget-content" id="ui-id-12" aria-labelledby="ui-id-11" role="tabpanel" aria-hidden="true">
                                    <p className='p5-question'>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز</p>
                                </div>
                                <h3 className="ui-accordion-header ui-corner-top ui-accordion-header-collapsed ui-corner-all ui-state-default ui-accordion-icons" role="tab" id="ui-id-13" aria-controls="ui-id-14" aria-selected="false" aria-expanded="false" tabindex="-1"><span className="ui-accordion-header-icon ui-icon ui-icon-triangle-1-e"></span>چرا بیشتر سوالات اینجاست؟ </h3>
                                <div className="ui-accordion-content ui-corner-bottom ui-helper-reset ui-widget-content" id="ui-id-14" aria-labelledby="ui-id-13" role="tabpanel" aria-hidden="true">
                                    <p className='p6-question'>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز</p>
                                </div>
                                <h3 className="ui-accordion-header ui-corner-top ui-accordion-header-collapsed ui-corner-all ui-state-default ui-accordion-icons" role="tab" id="ui-id-15" aria-controls="ui-id-16" aria-selected="false" aria-expanded="false" tabindex="-1"><span className="ui-accordion-header-icon ui-icon ui-icon-triangle-1-e"></span>سوالات پر تکرار هفتم اینجاست؟ </h3>
                                <div className="ui-accordion-content ui-corner-bottom ui-helper-reset ui-widget-content" id="ui-id-16" aria-labelledby="ui-id-15" role="tabpanel" aria-hidden="true">
                                    <p className='p7-question'>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </section>
    </div>
  )
}
