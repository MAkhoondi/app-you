import React from 'react'
import './Header.css'
import NavBar from '../NavBar/NavBar'

export default function Header() {
  return (
    <div>
      <header className='home-area overlay'>
        <NavBar />
        <img className='headersite' src='./images/header-bg.jpg'></img>
      </header>
      <div className='container'>
        <div className='row'>
          <div className='col-xs-12 hidden-sm col-md-5'>
            <figure className='mobile-image '>
              <img src='./images/header-mobile.png'></img>
            </figure>
          </div>
          <div id='sub-header' className='col-xs-12 col-md-7'>
            <button id='download' href="#" class="bttn-white wow fadeInUp">
              <svg id='d-icon' xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="size-6">
                <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5M16.5 12 12 16.5m0 0L7.5 12m4.5 4.5V3" />
              </svg>
              دانلود برنامه
            </button>
            <div className="space-80 hidden-xs"></div>
            <h1 className="h-h1 wow fadeInUp">کارهای شگفت انگیز خود را از<br/> طریق اپ یو شروع کنید.</h1>
            <div className="space-20"></div>
            <div className="desc wow fadeInUp">
              <p className='h-span'>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز</p>
            </div>
            <div className="space-20"></div>
          </div>
      </div>
    </div>
</div>
  )
}
