import React from 'react'
import './Video.css'

export default function Video() {
  return (
    <div>
      <section className="video-area sectioon-padding">
        <img className='v-bg' src='./images/video-bg.jpg'></img>
        <div className="container">
          <div className="row">
            <div className="col-xs-12 col-md-6">
              <div className="video-photo" id='up-lay'>
                <img className='v-photo' src="./images/video-image.jpg" alt=""></img>
                  <a href="https://www.youtube.com/watch?v=ScrDhTsX0EQ" className="popup video-button">
                    <img src="./images/play-button.png" alt=""></img>
                  </a>
              </div>
            </div>
            <div className="col-xs-12 col-md-5 col-md-offset-1">
                <div className="space-60 hidden visible-xs"></div>
                <div className="ppage-title">
                    <h5 className="v-h5 wow fadeInUp">ویژگی های ویدئو</h5>
                    <div className="space-10"></div>
                    <h3 className="ddark-color wow fadeInUp">برنامه گرت برای همیشه</h3>
                    <div className="space-20"></div>
                    <div className="desc wow fadeInUp">
                      <p className='pv-video'>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان<br/> گرافیک است چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است</p>
                    </div>
                    <div className="space-50"></div>
                    <button href="#" className="know-bttn wow fadeInUp"><span className='p-video'>بیشتر بدانید</span></button>
                </div>
            </div>
        </div>
    </div>
  </section>
</div>
  )
}
