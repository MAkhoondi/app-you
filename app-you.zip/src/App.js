import logo from './logo.svg';
import './App.css';
import Header from './Header/Header';
import About from './About/About';
import Progress from './Progress/Progress';
import Video from './Video/Video';
import Features from './Features/Features';
import Comments from './Comments/Comments';
import Screenshots from './Screenshots/Screenshots';
import FeaturesUs from './FeaturesUs/FeaturesUs';
import Download from './Download/Download';
import Prices from './Prices/Prices';
import Questions from './Questions/Questions';
import Newsletter from './Newsletter/Newsletter';
import Footer from './Footer/Footer';
import ScrollUp from './ScrollUp/ScrollUp';

function App() {
  return (
    <div>
      <Header />
      <About />
      <Progress />
      <Video />
      <Features />
      <Comments />
      <Screenshots />
      <FeaturesUs />
      <Download />
      <Prices />
      <Questions />
      <Newsletter />
      <Footer />
      <ScrollUp />
    </div>
  );
}

export default App;
